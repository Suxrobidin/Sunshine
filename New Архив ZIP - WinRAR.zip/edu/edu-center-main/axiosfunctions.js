var deletedStudentId = '';

async function CheckUser(){
    let user = '';
    var username = document.getElementById('logininput').value;
    var password = document.getElementById('passwordinput').value;
    await axios({
        method: 'post',
        url: 'https://localhost:7094/api/Account/Login/login',
        
        data: {
          username: username,
          password: password
        }
      }).then(response => (user = response.data))
      .catch(function(){
        console.log('Error');
      });
      if (user.roles.includes("Admin")){
        sessionStorage.setItem("token", user.token);
        window.location.href = "index.html";
      }
}

async function GetDashboardInfo(){
    GetAdminInfo();
    var token = sessionStorage.getItem("token");
    let numbers = '';
    await axios({
      method: 'get',
      url: 'https://localhost:7094/api/Info/AdminDashboardInfo',
      params: {
        token : token
      }
    }).then(response => (numbers = response.data))
    .catch(function(){
      console.log('Error');
    });
    document.getElementById("group-number").innerHTML = numbers.numberOfGroups;
    document.getElementById("teacher-number").innerHTML = numbers.numberOfTeachers;
    document.getElementById("student-number").innerHTML = numbers.numberOfStudents;
    document.getElementById("deadline-days").innerHTML = numbers.deadlineDays;
  }
  
  async function GetAdminInfo(){
    let user = '';
    var token = sessionStorage.getItem("token");
  
    await axios({
      method: 'get',
      url: 'https://localhost:7094/api/Account/GetUserInfo',
      params: {
        token : token
      }
    }).then(response => (user = response.data))
    .catch(function(){
      console.log('Error');
    });
    document.getElementById("admin-name").innerHTML = user.firstName + " " + user.lastName;
  }

  async function GetAllGroups(){
    GetAdminInfo();
    let groups = '';
    var token = sessionStorage.getItem("token");
    await axios({
      method: 'get',
      url: 'https://localhost:7094/api/Group/GetAll',
      params: {
        token : token
      }
    }).then(response => (groups = response.data))
    .catch(function(){
      console.log('Error');
    });
    for (let i = 0, container = document.getElementById("group-table"); i < groups.length; i++) {
      const group = groups[i];
      
      const new_group = `<tr class="table-el">
      <th class="text-center" scope="row">${i+1}</th>
      <td>${group.name}</td>
      <td>${group.teacher.firstname + " " + group.teacher.lastname}</td>
      <td>${group.course.name}</td>
      <td>${group.startTime + " - " + group.endTime}<br>${group.days}</td>
      <td>${group.students.length}</td>
      <td>${group.createdTime}</td>
      <td class="text-center">
          <a href="#"><button class="table-buttons button1"><i class="fa-solid fa-pencil"></i></button></a>
          <a href="./group-member.html"><button class="table-buttons button2"><i class="fa-solid fa-eye"></i></button></a>
          <a href="#"><button class="table-buttons button3"><i class="fa-solid fa-trash-can"></i></button></a>
      </td>
     </tr>`;
      container.insertAdjacentHTML("beforeend", new_group);
      }
  }

  async function GetAllTeachers(){
    GetAdminInfo();
  
    let teachers = '';
    var token = sessionStorage.getItem("token");
    await axios({
      method: 'get',
      url: 'https://localhost:7094/api/Teacher/GetAll',
      params: {
        token : token
      }
    }).then(response => (teachers = response.data))
    .catch(function(){
      console.log('Error');
    });
    for (let i = 0, container = document.getElementById("teacher-table"); i < teachers.length; i++) {
      const teacher = teachers[i];
      
      const new_teacher = `<tr class="table-el table-item">
      <th class="text-center" scope="row">${i+1}</th>
      <td>${teacher.firstname + " " + teacher.lastname}</td>
      <td>${teacher.age}</td>
      <td>${teacher.phoneNumber}</td>
      <td>${teacher.gender}</td>
      <td>${teacher.experienceYears}</td>
      <td>${teacher.salaryPercentage}%</td>
      <td class="text-center">
          <a href="./addteacher.html"><button class="table-buttons button1"><i class="fa-solid fa-pencil"></i></button></a>
          <a href="./group-member.html"><button class="table-buttons button2"><i class="fa-solid fa-eye"></i></button></a>
          <a href="#"><button class="table-buttons button3"><i class="fa-solid fa-trash-can"></i></button></a>
      </td>
     </tr>`;
      container.insertAdjacentHTML("beforeend", new_teacher);
      }
  }

  // ADD TEACHER

  async function GetSpecialities(){
    GetAdminInfo();
    let specialities = '';
    var token = sessionStorage.getItem("token");
    await axios({
        method: 'get',
        url: 'https://localhost:7094/api/Speciality/GetAll',
        params: {
          token : token
        }
      }).then(response => (specialities = response.data))
      .catch(function(){
        console.log('Error');
      });
      for (let i = 0, container = document.getElementById("list-specialities"); i < specialities.length; i++) {
        const speciality = specialities[i];
        
        const new_speciality = 
            `<li class="option" id="option1">
                <span class="option-text" id="option-text1">${speciality.name}</span>
            </li>`;
        container.insertAdjacentHTML("beforeend", new_speciality);
        }
  }

async function AddTeacher(){
    let result = '';
    var token = sessionStorage.getItem("token");
    var firstname = document.getElementById("firstname").value;
    var lastname = document.getElementById("lastname").value;
    var age = document.getElementById("age").value;
    var passport = document.getElementById("passport").value;
    var address = document.getElementById("adress").value;
    var phoneNumber = document.getElementById("phone-number").value;
    var addPhoneNumber = document.getElementById("add-phone-number").value;
    var email = document.getElementById("email").value;
    var experienceYears = document.getElementById("experience").value;
    var salaryPercentage = document.getElementById("salary").value;
    await axios({
      method: 'post',
      url: 'https://localhost:7094/api/Teacher/Add?token=' + token,
      data: {
        firstname : firstname,
        lastname : lastname,
        age : age,
        experienceYears : experienceYears,
        phoneNumber : phoneNumber,
        additionalPhoneNumber : addPhoneNumber,
        email : email,
        address : address,
        salaryPercentage : salaryPercentage
      }
    }).then(response => (result = true))
    .catch(function(){
      console.log('Error');
    });
    if (result == true){
      window.location.href = "teachers.html";
    }
  }

  // GET ALL STUDENTS

async function GetAllStudents(){
    GetAdminInfo();
  
    let students = '';
    var token = sessionStorage.getItem("token");
    await axios({
      method: 'get',
      url: 'https://localhost:7094/api/Student/GetAll',
      params: {
        token : token
      }
    }).then(response => (students = response.data))
    .catch(function(){
      console.log('Error');
    });
    for (let i = 0, container = document.getElementById("student-table"); i < students.length; i++) {
      const student = students[i];
      debugger;
      const new_student = `<tr class="table-el">
      <th class="text-center" scope="row">${i + 1}</th>
      <td>${student.firstname + " " + student.lastname}</td>
      <td>${student.age}</td>
      <td>${student.phoneNumber}</td>
      <td>${student.gender}</td>
      <td>${student.isPrivileged == true ? "Yes" : "No"}</td>
      <td>21/04/2023</td>
      <td class="text-center">
          <a href="./addteacher.html"><button class="table-buttons button1"><i class="fa-solid fa-pencil"></i></button></a>
          <a href="./group-member.html"><button class="table-buttons button2"><i class="fa-solid fa-eye"></i></button></a>
          <button onclick="GetDeleteStudentId(${student.id})" type="button" class="table-buttons button3" data-bs-toggle="modal" data-bs-target="#staticBackdrop"><i class="fa-solid fa-trash-can"></i></button>
      </td>
      </tr>
     `;
      container.insertAdjacentHTML("beforeend", new_student);
      }
  }

  function GetDeleteStudentId(id){
    debugger;
    sessionStorage.setItem("deletedId", id);
    debugger;
  }

  async function DeleteStudent(){
    var token = sessionStorage.getItem("token");
    let id = sessionStorage.getItem("deletedId");
    let result = false;
debugger;
    await axios({
      method: 'delete',
      url: 'https://localhost:7094/api/Student/Delete?Id=' + id + '&token=' + token,
      params: {
      }
    }).then(response => (result = true))
    .catch(function(){
      console.log('Error');
    });
    if(result == true)
    {
      window.location.href = "students.html";
    }
  }

  // ADD STUDENT

  async function AddStudent(){
    let result = '';
    var token = sessionStorage.getItem("token");
    var firstname = document.getElementById("firstname").value;
    var lastname = document.getElementById("lastname").value;
    var age = document.getElementById("age").value;
    var phoneNumber = document.getElementById("phone-number").value;
    var addPhoneNumber = document.getElementById("add-phone-number").value;
    var email = document.getElementById("email").value;
    var description = document.getElementById("description").value;
    var remember = document.getElementById('isprivileged');
    var username = document.getElementById('username').value;
    var password = document.getElementById('password').value;
    var gender = document.querySelector('input[name="gender"]:checked').value;
    await axios({
      method: 'post',
      url: 'https://localhost:7094/api/Student/Add?token=' + token,
      data: {
        firstname : firstname,
        lastname : lastname,
        age : age,
        phoneNumber : phoneNumber,
        additionalPhoneNumber : addPhoneNumber,
        email : email,
        gender : gender,
        isPrivileged : remember.checked,
        privilegeDescription : description,
        username : username,
        password : password
      }
    }).then(response => (result = true))
    .catch(function(){
      console.log('Error');
    });
    if (result == true){
      window.location.href = "students.html";
    }
  }